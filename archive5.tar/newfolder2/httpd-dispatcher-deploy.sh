#!/bin/bash
#stop httpd service
echo "\n============ Stopping httpd Service ============\n"
sudo service httpd stop
#perform clean up of previous deployment backup
echo "\n============ Performing Cleanup of old zip and tar files ============\n"
cd /etc/httpd
sudo rm -rf aem-vhigroupservices-project.dispatcher.ams-0.0.1-SNAPSHOT.zip default-conf.tar

#back up previous deployment
echo "\n============ Creating backup of previous deployment ============\n"
sudo tar -zcvf default-conf.tar /etc/httpd/conf*
 
#perform clean up of previous deployment
echo "\n============ Performing Cleanup on Httpd dir ============\n"
sudo rm -rf conf*

# copy new zipfile to /etc/httpd 
echo "\n============ Deploying dispathcer ============\n"
sudo cp /tmp/aem-vhigroupservices-project.dispatcher.ams-0.0.1-SNAPSHOT.zip /etc/httpd/
#unzip to /etc/httpd
sudo unzip aem-vhigroupservices-project.dispatcher.ams-0.0.1-SNAPSHOT.zip

#start httpd
echo "\n============ Starting Httpd service ============\n"
sudo service httpd start
sudo service httpd status
