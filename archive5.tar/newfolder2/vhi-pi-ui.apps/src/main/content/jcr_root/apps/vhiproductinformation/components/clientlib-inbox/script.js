
(function ($, $document) {

    var isWorkFlow = false;

	// hide delegate action in work item
    $document.on("foundation-contentloaded", function() {

		let openPage = "/libs/cq/inbox/content/inbox/details/workitem.html";
        let pathName = window.location.pathname;

        if(pathName.indexOf(openPage) == 0) {

            let contentPath = $("input[name='modelTitle']").val();
            if (contentPath.includes("VHIContentFragmentApproval")) {
                // adding back the delegate button for scenario testing
                // $(".inbox-details-workitem-action--delegate").addClass("foundation-collection-action-hidden");
            }

        }


	// hide delegate action in work item
    $document.on("click", ".foundation-collection-item", function(item) {
		let workflow = "vhicontentfragmentapproval";
        let selector = ".foundation-selections-item";
        let row = $(item.target).closest(selector);
        let itemWorkFlow = $(row).data("foundation-collection-item-id");

        if(itemWorkFlow.includes(workflow)) {
            isWorkFlow = true;
            // adding back the delegate button for scenario testing
			//$(".cq-inbox-workitem-delegate").addClass("foundation-collection-action-hidden");
        } else {
			isWorkFlow = false;
        }
    });


    // for mandatory comment field in step back
    $document.on("coral-overlay:open", function(event) {

        var logicIndicator = $(".coral3-SelectList-item").text();
        let openPage = "/libs/cq/inbox/content/inbox/details/workitem.html";
        let pathName = window.location.pathname;
        var commentLabel = $(".cq-inbox-dialog-injection-anchor + .coral-Form-fieldwrapper .coral-Form-fieldlabel").text();

        if (isWorkFlow && logicIndicator.includes("pi-author") || pathName.indexOf(openPage) == 0) {

        	if (commentLabel === "Comment") {
				$(".cq-inbox-dialog-injection-anchor + .coral-Form-fieldwrapper .coral-Form-fieldlabel").append(" *");
        	}

            $(".coral3-Textfield").attr("aria-required", "true");

        } else {
			$(".coral3-Textfield").removeAttr("aria-required").removeClass("is-invalid");
            $(".coral-Form-fielderror").hide();
            $(".cq-inbox-dialog-injection-anchor + .coral-Form-fieldwrapper .coral-Form-fieldlabel").text("Comment");
        }

        if (!logicIndicator.includes("pi-author")) {
			$(".coral3-Textfield").removeAttr("aria-required").removeClass("is-invalid");
            $(".coral-Form-fielderror").hide();
            $(".cq-inbox-dialog-injection-anchor + .coral-Form-fieldwrapper .coral-Form-fieldlabel").text("Comment");
        }

    });


});

})(jQuery, jQuery(document));